#include "librarian.h"

// Constructors/Destructors
//  

librarian::librarian () {
initAttributes();
}

librarian::~librarian () { }

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  

void librarian::initAttributes () {
}

