#include<iostream>
using namespace std;
int main(){
	int x,y;
	cout<<"Enter the two numbers"<<endl;
	cin>>x;
	cin>>y;
	if(x==y){
		cout<<"They are equal";
	}
	else{
		cout<<"They are not equal";
	}
}
