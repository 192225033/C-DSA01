#include "library.h"

// Constructors/Destructors
//  

library::library () {
initAttributes();
}

library::~library () { }

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  

void library::initAttributes () {
}

