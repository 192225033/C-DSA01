#include<iostream>
using namespace std;
class Animal{
	protected:
		string name,species;
		int age;
	public:
		Animal(string name,string species,int age){
			name=name;
			species=species;
			
		}
	
};
