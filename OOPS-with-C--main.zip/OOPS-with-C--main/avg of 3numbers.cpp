#include<iostream>
using namespace std;
int main(){
	int x,y,z;
	cout<<"Enter three numbers"<<endl;
	cin>>x;
	cin>>y;
	cin>>z;
	int avg=(x+y+z)/3;
	cout<<"The averaage is "<<avg;
	return 0;
}
