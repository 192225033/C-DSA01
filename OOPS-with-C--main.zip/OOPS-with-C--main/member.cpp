#include "member.h"

// Constructors/Destructors
//  

member::member () {
initAttributes();
}

member::~member () { }

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  

void member::initAttributes () {
}

